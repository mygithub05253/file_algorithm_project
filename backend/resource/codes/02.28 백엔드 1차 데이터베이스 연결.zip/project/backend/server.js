require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// ✅ 미들웨어 설정
app.use(express.json());
app.use(cors());

// ✅ MySQL 연결 (별도의 `connection.js` 파일 사용)
const db = require("./db/connection");

// ✅ 정적 파일 제공 (frontend 폴더)
app.use(express.static(path.join(__dirname, "../frontend")));

// ✅ 보호된 API 라우트 추가
const protectedRoutes = require("./routes/protectedRoutes");
app.use("/protected", protectedRoutes);

// ✅ 회원가입 & 로그인 라우트 추가
const authRoutes = require("./routes/authRoutes");
app.use("/auth", authRoutes);

// ✅ 기본 API 라우트 (테스트용)
app.get("/", (req, res) => {
  res.send("🚀 백엔드 서버가 정상적으로 실행 중입니다!");
});

// ✅ 서버 실행
app.listen(PORT, () => {
  console.log(`🚀 서버 실행 중: http://localhost:${PORT}`);
});
