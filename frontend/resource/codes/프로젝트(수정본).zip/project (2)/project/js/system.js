let folders = JSON.parse(localStorage.getItem("folders")) || { "전체 파일": []};
let currentTab = "전체 파일";

function saveFolders() {
    localStorage.setItem("folders", JSON.stringify(folders));
}

function loadFoldersFromStorage() {
    let storedFolders = JSON.parse(localStorage.getItem("folders"));
    if (!storedFolders) {
        storedFolders = { "전체 파일": [], };
        localStorage.setItem("folders", JSON.stringify(storedFolders));
    }
    return storedFolders;
}

function loadCategories() {
    const folderTabs = document.getElementById("folderTabs");
    folderTabs.innerHTML = "";
    const folderSelect = document.getElementById("folderSelect");
    folderSelect.innerHTML = "";
    
    Object.keys(folders).forEach(folder => {
        const button = document.createElement("button");
        button.classList.add("tab");
        button.innerHTML = `📁 <span>${folder}</span>`;
        if (folder !== "전체 파일") {
            const removeButton = document.createElement("button");
            removeButton.innerHTML = "❌";
            removeButton.onclick = (e) => {
                e.stopPropagation();
                removeCategory(folder);
            };
            button.appendChild(removeButton);
        }
        button.onclick = () => changeTab(folder);
        folderTabs.appendChild(button);

        const option = document.createElement("option");
        option.value = folder;
        option.textContent = folder;
        folderSelect.appendChild(option);
    });
}

function createCategory() {
    const newCategory = document.getElementById("newCategoryName").value.trim();
    if (newCategory && !folders[newCategory]) {
        folders[newCategory] = [];
        saveFolders();
        loadCategories();
    }
    document.getElementById("newCategoryName").value = "";
}

function removeCategory(category) {
    if (category === "전체 파일") return;
    delete folders[category];
    saveFolders();
    loadCategories();
    changeTab("전체 파일");
}

function changeTab(folderName) {
    currentTab = folderName;
    document.getElementById("folderTitle").innerText = `📁 ${folderName}`;
    displayFiles();
}

function uploadFiles() {
    const input = document.getElementById('fileInput');
    const files = input.files;
    const selectedFolder = document.getElementById("folderSelect").value;

    if (files.length === 0) {
        alert("파일을 선택하세요.");
        return;
    }

    for (let file of files) {
        const fileId = `${file.name}-${Date.now()}`;
        folders[selectedFolder].push({ id: fileId, name: file.name, date: new Date() });
    }

    input.value = "";  // 파일 선택 초기화
    saveFolders();
    displayFiles();
}

function sortFiles() {
    let sortOption = document.getElementById("sortOption").value;
    let fileList = document.getElementById("fileList");
    let files = Array.from(fileList.children);
    
    files.sort((a, b) => {
        let dateA = new Date(a.getAttribute("data-date"));
        let dateB = new Date(b.getAttribute("data-date"));
        
        return sortOption === "latest" ? dateB - dateA : dateA - dateB;
    });
    
    fileList.innerHTML = "";
    files.forEach(file => fileList.appendChild(file));
}

function displayFiles() {
    const fileList = document.getElementById("fileList");
    fileList.innerHTML = "";
    let allFiles = folders[currentTab] || [];
    
    if (allFiles.length === 0) {
        fileList.innerHTML = "<p>파일이 없습니다.</p>";
        return;
    }

    allFiles.forEach(fileObj => {
        const listItem = document.createElement("li");
        listItem.setAttribute("data-date", fileObj.date);
        listItem.innerHTML = `
            <input type="checkbox" class="fileCheckbox" data-id="${fileObj.id}">
            ${fileObj.name} (업로드 날짜: ${new Date(fileObj.date).toLocaleString()})
            <button onclick="downloadFile('${fileObj.id}')">📥 다운로드</button>
            <button onclick="deleteFile('${fileObj.id}')">🗑 삭제</button>
        `;
        fileList.appendChild(listItem);
    });
}


function deleteFile(fileId) {
    folders[currentTab] = folders[currentTab].filter(file => file.id !== fileId);
    saveFolders();
    
    displayFiles();
}


function downloadFile(fileId) {
    const file = folders[currentTab].find(file => file.id === fileId);
    if (file) {
        alert(`${file.name} 다운로드 시작 (서버 구현 필요)`);
    } else {
        alert("파일을 찾을 수 없습니다.");
    }
}

// 모든 파일을 선택 또는 해제하는 기능
function selectAllFiles(selectAll) {
    const checkboxes = document.querySelectorAll('.fileCheckbox');
    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAll;
    });
}

// 선택된 파일들을 다운로드
function downloadSelected() {
    const selectedFiles = getSelectedFiles();
    if (selectedFiles.length === 0) {
        alert("선택된 파일이 없습니다.");
        return;
    }

    selectedFiles.forEach(file => {
        alert(`${file.name} 다운로드 시작 (서버 구현 필요)`); // 각 파일을 개별적으로 다운로드
    });
}

// 선택된 파일들을 삭제
function deleteSelected() {
    const selectedFiles = getSelectedFiles();
    if (selectedFiles.length === 0) {
        alert("선택된 파일이 없습니다.");
        return;
    }

    if (confirm("선택한 파일을 삭제하시겠습니까?")) {
        selectedFiles.forEach(file => {
            folders[currentTab] = folders[currentTab].filter(f => f.id !== file.id);
        });
        saveFolders();
        displayFiles();
    }
}

// 모든 파일을 다운로드
function downloadAll() {
    const allFiles = folders[currentTab] || [];
    if (allFiles.length === 0) {
        alert("다운로드할 파일이 없습니다.");
        return;
    }

    allFiles.forEach(file => {
        alert(`${file.name} 다운로드 시작 (서버 구현 필요)`); // 모든 파일 다운로드
    });
}

// 선택된 파일들을 가져오는 함수
function getSelectedFiles() {
    const checkboxes = document.querySelectorAll('.fileCheckbox:checked');
    const selectedFiles = [];
    checkboxes.forEach(checkbox => {
        const fileId = checkbox.dataset.id;
        const file = folders[currentTab].find(f => f.id === fileId);
        if (file) {
            selectedFiles.push(file);
        }
    });
    return selectedFiles;
}


function logout() {
    alert("로그아웃 되었습니다.");
    window.location.href = "../html/index.html";
}

document.addEventListener("DOMContentLoaded", function() {
    folders = loadFoldersFromStorage();
    loadCategories();
});
